//This is the javascript file that should contain the functions of the site

